package com.w10play.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.w10play.app.databinding.ActivityEscolhaTipoBinding

class EscolhaTipoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEscolhaTipoBinding
    private var streaming: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityEscolhaTipoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        streaming = intent.getStringExtra("STREAMING") ?: ""

        // Botão Filmes
        binding.btnFilmes.setOnClickListener {
            abrirPlayer("filmes")
        }

        // Botão Séries
        binding.btnSeries.setOnClickListener {
            abrirPlayer("series")
        }
    }

    private fun abrirPlayer(tipo: String) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra("STREAMING", streaming)
        intent.putExtra("TIPO", tipo)
        startActivity(intent)
    }
}