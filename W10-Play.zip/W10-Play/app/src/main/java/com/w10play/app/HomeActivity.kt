package com.w10play.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.w10play.app.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Netflix
        binding.btnNetflix.setOnClickListener {
            abrirEscolha("netflix")
        }

        // Prime Video
        binding.btnPrime.setOnClickListener {
            abrirEscolha("prime")
        }

        // Disney+
        binding.btnDisney.setOnClickListener {
            abrirEscolha("disney")
        }

        // HBO Max
        binding.btnHbo.setOnClickListener {
            abrirEscolha("hbo")
        }

        // Apple TV+
        binding.btnApple.setOnClickListener {
            abrirEscolha("apple")
        }

        // Globoplay
        binding.btnGlobo.setOnClickListener {
            abrirEscolha("globo")
        }
    }

    private fun abrirEscolha(streaming: String) {
        val intent = Intent(this, EscolhaTipoActivity::class.java)
        intent.putExtra("STREAMING", streaming)
        startActivity(intent)
    }
}